import { DaySummary, MoodType, RoutineEntry } from '../types';

const INDONESIAN_DAYS = [
  'Minggu',
  'Senin',
  'Selasa',
  'Rabu',
  'Kamis',
  'Jumat',
  'Sabtu',
];

const INDONESIAN_MONTHS = [
  'Januari',
  'Februari',
  'Maret',
  'April',
  'Mei',
  'Juni',
  'Juli',
  'Agustus',
  'September',
  'Oktober',
  'November',
  'Desember',
];

/**
 * Returns YYYY-MM-DD format for a given Date object (local timezone)
 */
export function toDateString(d: Date = new Date()): string {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Returns Indonesian formatted date: e.g. "Minggu, 13 September 2026"
 */
export function formatIndonesianDate(dateStringOrDate: string | Date, withDay = true): string {
  let date: Date;
  if (typeof dateStringOrDate === 'string') {
    const [year, month, day] = dateStringOrDate.split('-').map(Number);
    if (!year || !month || !day) {
      date = new Date();
    } else {
      date = new Date(year, month - 1, day);
    }
  } else {
    date = dateStringOrDate;
  }

  const dayName = INDONESIAN_DAYS[date.getDay()];
  const dayNum = date.getDate();
  const monthName = INDONESIAN_MONTHS[date.getMonth()];
  const year = date.getFullYear();

  if (withDay) {
    return `${dayName}, ${dayNum} ${monthName} ${year}`;
  }
  return `${dayNum} ${monthName} ${year}`;
}

/**
 * Returns current local time in HH:MM
 */
export function getCurrentTimeString(): string {
  const now = new Date();
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  return `${hours}:${minutes}`;
}

/**
 * Navigate day offset
 */
export function addDays(dateStr: string, offset: number): string {
  const [year, month, day] = dateStr.split('-').map(Number);
  const d = new Date(year, month - 1, day);
  d.setDate(d.getDate() + offset);
  return toDateString(d);
}

/**
 * Checks if dateStr is today
 */
export function isToday(dateStr: string): boolean {
  return dateStr === toDateString(new Date());
}

/**
 * Computes day summary statistics from an array of entries
 */
export function calculateDaySummary(entries: RoutineEntry[]): DaySummary {
  if (!entries || entries.length === 0) {
    return {
      totalCount: 0,
      dominantMood: null,
      firstActivityTime: null,
      lastActivityTime: null,
    };
  }

  // Sort by time ascending
  const sorted = [...entries].sort((a, b) => a.time.localeCompare(b.time));

  // Find dominant mood
  const moodCounts: Record<string, number> = {};
  for (const entry of entries) {
    moodCounts[entry.mood] = (moodCounts[entry.mood] || 0) + 1;
  }

  let dominantMood: MoodType = sorted[0].mood;
  let maxCount = 0;
  for (const [mood, count] of Object.entries(moodCounts)) {
    if (count > maxCount) {
      maxCount = count;
      dominantMood = mood as MoodType;
    }
  }

  return {
    totalCount: entries.length,
    dominantMood,
    firstActivityTime: sorted[0].time,
    lastActivityTime: sorted[sorted.length - 1].time,
  };
}
