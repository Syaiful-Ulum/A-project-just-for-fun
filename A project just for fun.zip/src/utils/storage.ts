import { STORAGE_KEYS } from '../constants';
import { RoutineEntry } from '../types';
import { toDateString } from './dateUtils';

export function getStoredUserName(): string {
  try {
    return localStorage.getItem(STORAGE_KEYS.USER_NAME) || '';
  } catch (e) {
    console.error('Failed to read user name from localStorage', e);
    return '';
  }
}

export function setStoredUserName(name: string): void {
  try {
    localStorage.setItem(STORAGE_KEYS.USER_NAME, name.trim());
  } catch (e) {
    console.error('Failed to save user name to localStorage', e);
  }
}

export function getStoredEntries(): RoutineEntry[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.ENTRIES);
    if (!raw) {
      return [];
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) {
      return parsed;
    }
    return [];
  } catch (e) {
    console.error('Failed to load entries from localStorage', e);
    return [];
  }
}

export function saveStoredEntries(entries: RoutineEntry[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.ENTRIES, JSON.stringify(entries));
  } catch (e) {
    console.error('Failed to save entries to localStorage', e);
  }
}

export function getSampleEntries(): RoutineEntry[] {
  const today = toDateString(new Date());
  return [
    {
      id: 'sample-1',
      date: today,
      time: '07:30',
      story: 'Bangun pagi lebih segar, minum air hangat dan stretching sebentar di teras.',
      mood: 'Tenang',
      createdAt: Date.now() - 1000 * 60 * 180,
    },
    {
      id: 'sample-2',
      date: today,
      time: '09:15',
      story: 'Mulai fokus mengerjakan tugas harian dan merapikan catatan kerja.',
      mood: 'Semangat',
      createdAt: Date.now() - 1000 * 60 * 120,
    },
    {
      id: 'sample-3',
      date: today,
      time: '12:40',
      story: 'Makan siang santai sambil ngobrol ringan, pikiran jadi lebih rileks.',
      mood: 'Senang',
      createdAt: Date.now() - 1000 * 60 * 60,
    },
  ];
}
