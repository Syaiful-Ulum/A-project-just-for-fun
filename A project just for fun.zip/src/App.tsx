import React, { useState, useEffect, useCallback } from 'react';
import { ActiveTab, MoodType, RoutineEntry } from './types';
import {
  getStoredEntries,
  getStoredUserName,
  saveStoredEntries,
  setStoredUserName,
  getSampleEntries,
} from './utils/storage';
import {
  calculateDaySummary,
  formatIndonesianDate,
  isToday,
  toDateString,
} from './utils/dateUtils';
import { MOOD_OPTIONS } from './constants';
import { Header } from './components/Header';
import { WelcomeBanner } from './components/WelcomeBanner';
import { DateNavigator } from './components/DateNavigator';
import { DailyStats } from './components/DailyStats';
import { RoutineForm } from './components/RoutineForm';
import { RoutineList } from './components/RoutineList';
import { EmptyState } from './components/EmptyState';
import { HistoryView } from './components/HistoryView';
import { AboutView } from './components/AboutView';
import { UsageGuideModal } from './components/UsageGuideModal';
import { ShareModal } from './components/ShareModal';
import { Toast } from './components/Toast';
import { BottomNav } from './components/BottomNav';

export default function App() {
  const [userName, setUserName] = useState<string>('');
  const [entries, setEntries] = useState<RoutineEntry[]>([]);
  const [selectedDate, setSelectedDate] = useState<string>(() => toDateString(new Date()));
  const [activeTab, setActiveTab] = useState<ActiveTab>('today');
  const [isGuideOpen, setIsGuideOpen] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Share modal state
  const [shareModal, setShareModal] = useState<{
    isOpen: boolean;
    title: string;
    text: string;
  }>({
    isOpen: false,
    title: '',
    text: '',
  });

  // Load initial data from localStorage
  useEffect(() => {
    const storedName = getStoredUserName();
    const storedEntries = getStoredEntries();
    setUserName(storedName);
    setEntries(storedEntries);
  }, []);

  // Show toast with auto dismiss
  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    const timer = setTimeout(() => {
      setToastMessage(null);
    }, 3000);
    return () => clearTimeout(timer);
  }, []);

  // Save user name
  const handleSaveUserName = (name: string) => {
    setUserName(name);
    setStoredUserName(name);
    showToast(`Nama disimpan: ${name} 👋`);
  };

  // Add new routine entry
  const handleAddEntry = ({
    time,
    story,
    mood,
  }: {
    time: string;
    story: string;
    mood: MoodType;
  }) => {
    const newEntry: RoutineEntry = {
      id: 'entry-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7),
      date: selectedDate,
      time,
      story,
      mood,
      createdAt: Date.now(),
    };

    const updated = [newEntry, ...entries];
    setEntries(updated);
    saveStoredEntries(updated);
    showToast('Catatan berhasil disimpan ✓');
  };

  // Update an existing entry
  const handleUpdateEntry = (
    id: string,
    updatedData: { time: string; story: string; mood: MoodType }
  ) => {
    const updated = entries.map((entry) =>
      entry.id === id ? { ...entry, ...updatedData } : entry
    );
    setEntries(updated);
    saveStoredEntries(updated);
    showToast('Catatan berhasil diperbarui ✓');
  };

  // Delete an entry
  const handleDeleteEntry = (id: string) => {
    const updated = entries.filter((entry) => entry.id !== id);
    setEntries(updated);
    saveStoredEntries(updated);
    showToast('Catatan dihapus');
  };

  // Load sample entries for preview
  const handleLoadSample = () => {
    const sample = getSampleEntries();
    const merged = [...sample, ...entries];
    setEntries(merged);
    saveStoredEntries(merged);
    if (!userName) {
      setUserName('Teman');
      setStoredUserName('Teman');
    }
    showToast('Contoh catatan berhasil dimuat ✨');
  };

  // Clear all data
  const handleClearAllData = () => {
    setEntries([]);
    setUserName('');
    saveStoredEntries([]);
    setStoredUserName('');
    showToast('Semua data berhasil dibersihkan');
  };

  // Filter entries for the selected date
  const selectedDateEntries = entries.filter((e) => e.date === selectedDate);
  const daySummary = calculateDaySummary(selectedDateEntries);
  const isCurrentDateToday = isToday(selectedDate);

  // Generate share text for a whole day
  const generateDayShareText = (dateToShare: string) => {
    const dayItems = entries
      .filter((e) => e.date === dateToShare)
      .sort((a, b) => a.time.localeCompare(b.time));

    const dateFormatted = formatIndonesianDate(dateToShare, true);
    const summary = calculateDaySummary(dayItems);
    const moodObj = MOOD_OPTIONS.find((m) => m.id === summary.dominantMood);

    let text = `SHARE DAILY ROUTINE\n${dateFormatted}\n\n`;

    if (summary.dominantMood) {
      text += `${moodObj?.emoji || '😊'} Mood Dominan: ${summary.dominantMood}\n\n`;
    }

    if (dayItems.length === 0) {
      text += `Belum ada catatan aktivitas pada tanggal ini.\n`;
    } else {
      dayItems.forEach((item) => {
        const itemMood = MOOD_OPTIONS.find((m) => m.id === item.mood);
        text += `${item.time}\n${item.story} (${itemMood?.emoji || ''} ${item.mood})\n\n`;
      });
    }

    text += `— Dicatat melalui Share Daily Routine`;
    return text;
  };

  // Generate share text for a single note
  const generateSingleShareText = (entry: RoutineEntry) => {
    const dateFormatted = formatIndonesianDate(entry.date, true);
    const moodObj = MOOD_OPTIONS.find((m) => m.id === entry.mood);
    return `SHARE DAILY ROUTINE\n${dateFormatted}\n\n${entry.time} • ${moodObj?.emoji || ''} ${entry.mood}\n"${entry.story}"\n\n— Catat harimu, kenali dirimu.`;
  };

  const handleOpenShareDay = (dateStr: string = selectedDate) => {
    const text = generateDayShareText(dateStr);
    const dateTitle = formatIndonesianDate(dateStr, true);
    setShareModal({
      isOpen: true,
      title: `Bagikan Rutinitas (${dateTitle})`,
      text,
    });
  };

  const handleOpenShareSingle = (entry: RoutineEntry) => {
    const text = generateSingleShareText(entry);
    setShareModal({
      isOpen: true,
      title: `Bagikan Catatan (${entry.time})`,
      text,
    });
  };

  const handleFocusForm = () => {
    const textarea = document.getElementById('routine-story-input');
    if (textarea) {
      textarea.focus();
      textarea.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  const todayEntriesCount = entries.filter((e) => isToday(e.date)).length;

  return (
    <div className="min-h-screen bg-[#f8fafc] text-slate-800 flex flex-col antialiased pb-20 sm:pb-12">
      {/* Top Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenGuide={() => setIsGuideOpen(true)}
        entriesCount={todayEntriesCount}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-5xl w-full mx-auto px-4 sm:px-6 py-5 sm:py-8 space-y-6">
        {/* TAB 1: HARI INI */}
        {activeTab === 'today' && (
          <div className="space-y-6 animate-in fade-in duration-150">
            {/* 1. Welcome / User Identification Section */}
            <WelcomeBanner
              userName={userName}
              onSaveName={handleSaveUserName}
            />

            {/* 2. Date Navigator */}
            <DateNavigator
              currentDate={selectedDate}
              onSelectDate={(newDate) => setSelectedDate(newDate)}
            />

            {/* 3. Daily Summary Stats Card */}
            <DailyStats
              summary={daySummary}
              isTodayDate={isCurrentDateToday}
              onShare={() => handleOpenShareDay(selectedDate)}
            />

            {/* 4. Form to add new daily note */}
            <RoutineForm
              userName={userName}
              selectedDate={selectedDate}
              onAddEntry={handleAddEntry}
              onRequireName={() => {
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
            />

            {/* 5. List of today's notes or Empty State */}
            {selectedDateEntries.length > 0 ? (
              <RoutineList
                entries={selectedDateEntries}
                isTodayDate={isCurrentDateToday}
                onUpdateEntry={handleUpdateEntry}
                onDeleteEntry={handleDeleteEntry}
                onShareSingle={handleOpenShareSingle}
              />
            ) : (
              <EmptyState
                onFocusForm={handleFocusForm}
                onLoadSample={handleLoadSample}
                isTodayDate={isCurrentDateToday}
              />
            )}
          </div>
        )}

        {/* TAB 2: RIWAYAT */}
        {activeTab === 'history' && (
          <div className="animate-in fade-in duration-150">
            <HistoryView
              entries={entries}
              onSelectDate={(date) => {
                setSelectedDate(date);
                setActiveTab('today');
              }}
              onShareDay={(date) => handleOpenShareDay(date)}
            />
          </div>
        )}

        {/* TAB 3: TENTANG */}
        {activeTab === 'about' && (
          <div className="animate-in fade-in duration-150">
            <AboutView
              onClearAllData={handleClearAllData}
              entriesCount={entries.length}
            />
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="mt-auto border-t border-slate-200/80 bg-white/70 py-6 text-center text-xs text-slate-500">
        <div className="max-w-5xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <p className="font-medium text-slate-600">
            Share Daily Routine • <span className="text-slate-400">Catat harimu. Kenali dirimu.</span>
          </p>
          <p className="text-slate-400">
            Tersimpan lokal di perangkatmu • Bebas login & tanpa iklan
          </p>
        </div>
      </footer>

      {/* Mobile Bottom Navigation */}
      <BottomNav
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        entriesCountToday={todayEntriesCount}
      />

      {/* Usage Guide Modal */}
      <UsageGuideModal
        isOpen={isGuideOpen}
        onClose={() => setIsGuideOpen(false)}
      />

      {/* Share Modal */}
      <ShareModal
        isOpen={shareModal.isOpen}
        onClose={() => setShareModal({ ...shareModal, isOpen: false })}
        title={shareModal.title}
        shareText={shareModal.text}
        onCopied={() => showToast('Ringkasan disalin ke clipboard ✓')}
      />

      {/* Toast Notification */}
      <Toast
        message={toastMessage}
        onClose={() => setToastMessage(null)}
      />
    </div>
  );
}
