import { MoodOption, MoodType } from './types';

export const MOOD_OPTIONS: MoodOption[] = [
  {
    id: 'Senang',
    label: 'Senang',
    emoji: '😊',
    accentColor: 'text-amber-700 border-amber-300 bg-amber-50 hover:bg-amber-100',
    badgeBg: 'bg-amber-100/80 text-amber-900 border-amber-200',
  },
  {
    id: 'Biasa saja',
    label: 'Biasa saja',
    emoji: '😐',
    accentColor: 'text-slate-700 border-slate-300 bg-slate-100 hover:bg-slate-200',
    badgeBg: 'bg-slate-100 text-slate-700 border-slate-200',
  },
  {
    id: 'Lelah',
    label: 'Lelah',
    emoji: '😴',
    accentColor: 'text-indigo-700 border-indigo-300 bg-indigo-50 hover:bg-indigo-100',
    badgeBg: 'bg-indigo-100/80 text-indigo-900 border-indigo-200',
  },
  {
    id: 'Kesal',
    label: 'Kesal',
    emoji: '😡',
    accentColor: 'text-rose-700 border-rose-300 bg-rose-50 hover:bg-rose-100',
    badgeBg: 'bg-rose-100/80 text-rose-900 border-rose-200',
  },
  {
    id: 'Sedih',
    label: 'Sedih',
    emoji: '😔',
    accentColor: 'text-blue-700 border-blue-300 bg-blue-50 hover:bg-blue-100',
    badgeBg: 'bg-blue-100/80 text-blue-900 border-blue-200',
  },
  {
    id: 'Bahagia',
    label: 'Bahagia',
    emoji: '😍',
    accentColor: 'text-pink-700 border-pink-300 bg-pink-50 hover:bg-pink-100',
    badgeBg: 'bg-pink-100/80 text-pink-900 border-pink-200',
  },
  {
    id: 'Semangat',
    label: 'Semangat',
    emoji: '🤩',
    accentColor: 'text-emerald-700 border-emerald-300 bg-emerald-50 hover:bg-emerald-100',
    badgeBg: 'bg-emerald-100/80 text-emerald-900 border-emerald-200',
  },
  {
    id: 'Tenang',
    label: 'Tenang',
    emoji: '😌',
    accentColor: 'text-teal-700 border-teal-300 bg-teal-50 hover:bg-teal-100',
    badgeBg: 'bg-teal-100/80 text-teal-900 border-teal-200',
  },
];

export const STORAGE_KEYS = {
  USER_NAME: 'sdr_user_name_v1',
  ENTRIES: 'sdr_entries_v1',
  HAS_SEEN_GUIDE: 'sdr_seen_guide_v1',
};

export const DEFAULT_MOOD: MoodType = 'Senang';
