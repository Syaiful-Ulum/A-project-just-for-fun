export type MoodType =
  | 'Senang'
  | 'Biasa saja'
  | 'Lelah'
  | 'Kesal'
  | 'Sedih'
  | 'Bahagia'
  | 'Semangat'
  | 'Tenang';

export interface MoodOption {
  id: MoodType;
  label: string;
  emoji: string;
  accentColor: string;
  badgeBg: string;
}

export interface RoutineEntry {
  id: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:MM
  story: string;
  mood: MoodType;
  createdAt: number;
}

export interface DaySummary {
  totalCount: number;
  dominantMood: MoodType | null;
  firstActivityTime: string | null;
  lastActivityTime: string | null;
}

export type ActiveTab = 'today' | 'history' | 'about';
