import React from 'react';
import { Calendar, Plus, Sparkles, Sprout } from 'lucide-react';

interface EmptyStateProps {
  onFocusForm: () => void;
  onLoadSample: () => void;
  isTodayDate: boolean;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  onFocusForm,
  onLoadSample,
  isTodayDate,
}) => {
  return (
    <div className="bg-white rounded-3xl p-8 sm:p-10 border border-slate-200/80 shadow-2xs text-center flex flex-col items-center justify-center">
      <div className="w-16 h-16 rounded-3xl bg-sky-50 border border-sky-100 flex items-center justify-center text-sky-600 mb-4 shadow-inner">
        <Sprout className="w-8 h-8 text-emerald-600" />
      </div>

      <h3 className="text-lg sm:text-xl font-bold text-slate-900 tracking-tight">
        Hari masih kosong 🌱
      </h3>
      <p className="text-slate-500 text-sm sm:text-base mt-1.5 max-w-sm">
        Catat satu hal kecil yang terjadi hari ini. Semua cerita berharga untuk diingat.
      </p>

      <div className="mt-6 flex flex-col sm:flex-row items-center gap-3">
        <button
          type="button"
          onClick={onFocusForm}
          className="w-full sm:w-auto px-6 py-3 rounded-2xl bg-sky-600 hover:bg-sky-700 text-white font-semibold text-sm transition-all shadow-sm shadow-sky-600/20 flex items-center justify-center gap-2 cursor-pointer"
        >
          <Plus className="w-4 h-4 stroke-[2.5]" />
          <span>+ Tambah Catatan</span>
        </button>

        <button
          type="button"
          onClick={onLoadSample}
          className="w-full sm:w-auto px-5 py-3 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs sm:text-sm transition-all cursor-pointer flex items-center justify-center gap-1.5"
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-500" />
          <span>Coba Contoh Catatan</span>
        </button>
      </div>
    </div>
  );
};
