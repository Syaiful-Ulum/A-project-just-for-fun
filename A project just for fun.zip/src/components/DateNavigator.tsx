import React, { useRef } from 'react';
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon, RotateCcw } from 'lucide-react';
import { addDays, formatIndonesianDate, isToday, toDateString } from '../utils/dateUtils';

interface DateNavigatorProps {
  currentDate: string;
  onSelectDate: (date: string) => void;
}

export const DateNavigator: React.FC<DateNavigatorProps> = ({
  currentDate,
  onSelectDate,
}) => {
  const dateInputRef = useRef<HTMLInputElement>(null);
  const isCurrentDateToday = isToday(currentDate);

  const handlePrevDay = () => {
    onSelectDate(addDays(currentDate, -1));
  };

  const handleNextDay = () => {
    onSelectDate(addDays(currentDate, 1));
  };

  const handleResetToToday = () => {
    onSelectDate(toDateString(new Date()));
  };

  const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.value) {
      onSelectDate(e.target.value);
    }
  };

  return (
    <div className="bg-white rounded-2xl p-3 sm:p-4 border border-slate-200/80 shadow-2xs flex flex-col sm:flex-row items-center justify-between gap-3">
      {/* Date shifting buttons */}
      <div className="flex items-center justify-between w-full sm:w-auto gap-2">
        <button
          type="button"
          onClick={handlePrevDay}
          className="flex items-center gap-1 px-3 py-2 rounded-xl text-xs sm:text-sm font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 transition-colors cursor-pointer"
          aria-label="Hari sebelumnya"
        >
          <ChevronLeft className="w-4 h-4" />
          <span className="hidden xs:inline">Hari Sebelumnya</span>
          <span className="xs:hidden">Kemarin</span>
        </button>

        <div className="text-center px-2">
          <div className="flex items-center justify-center gap-1.5">
            <span className="text-sm sm:text-base font-bold text-slate-800">
              {formatIndonesianDate(currentDate, true)}
            </span>
            {isCurrentDateToday && (
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-sky-100 text-sky-800">
                Hari Ini
              </span>
            )}
          </div>
        </div>

        <button
          type="button"
          onClick={handleNextDay}
          className="flex items-center gap-1 px-3 py-2 rounded-xl text-xs sm:text-sm font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 transition-colors cursor-pointer"
          aria-label="Hari berikutnya"
        >
          <span className="hidden xs:inline">Hari Berikutnya</span>
          <span className="xs:hidden">Besok</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      {/* Action shortcuts: Pick date & back to today */}
      <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
        {!isCurrentDateToday && (
          <button
            type="button"
            onClick={handleResetToToday}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold text-sky-700 bg-sky-50 hover:bg-sky-100 border border-sky-200/80 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Kembali ke Hari Ini</span>
          </button>
        )}

        <div className="relative">
          <input
            ref={dateInputRef}
            type="date"
            value={currentDate}
            onChange={handleDateChange}
            className="absolute inset-0 opacity-0 pointer-events-none w-0 h-0"
            tabIndex={-1}
          />
          <button
            type="button"
            onClick={() => {
              if (dateInputRef.current) {
                if ('showPicker' in HTMLInputElement.prototype) {
                  dateInputRef.current.showPicker();
                } else {
                  dateInputRef.current.focus();
                }
              }
            }}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs sm:text-sm font-semibold text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 transition-colors cursor-pointer"
          >
            <CalendarIcon className="w-4 h-4 text-sky-600" />
            <span>Pilih Tanggal</span>
          </button>
        </div>
      </div>
    </div>
  );
};
