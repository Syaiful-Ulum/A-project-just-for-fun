import React from 'react';
import { Calendar, History, Info } from 'lucide-react';
import { ActiveTab } from '../types';

interface BottomNavProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  entriesCountToday: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  setActiveTab,
  entriesCountToday,
}) => {
  return (
    <div className="sm:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200/90 py-1.5 px-6 shadow-lg shadow-slate-900/5">
      <div className="flex items-center justify-around max-w-md mx-auto">
        {/* Hari Ini */}
        <button
          type="button"
          onClick={() => setActiveTab('today')}
          className={`flex flex-col items-center gap-1 py-1 px-3 rounded-2xl transition-all cursor-pointer relative ${
            activeTab === 'today' ? 'text-sky-600 font-bold' : 'text-slate-400 font-medium'
          }`}
        >
          <Calendar className="w-5 h-5" />
          <span className="text-[11px] leading-none">Hari Ini</span>
          {entriesCountToday > 0 && (
            <span className="absolute top-0 right-2 w-2 h-2 rounded-full bg-sky-500 ring-2 ring-white" />
          )}
        </button>

        {/* Riwayat */}
        <button
          type="button"
          onClick={() => setActiveTab('history')}
          className={`flex flex-col items-center gap-1 py-1 px-3 rounded-2xl transition-all cursor-pointer ${
            activeTab === 'history' ? 'text-sky-600 font-bold' : 'text-slate-400 font-medium'
          }`}
        >
          <History className="w-5 h-5" />
          <span className="text-[11px] leading-none">Riwayat</span>
        </button>

        {/* Tentang */}
        <button
          type="button"
          onClick={() => setActiveTab('about')}
          className={`flex flex-col items-center gap-1 py-1 px-3 rounded-2xl transition-all cursor-pointer ${
            activeTab === 'about' ? 'text-sky-600 font-bold' : 'text-slate-400 font-medium'
          }`}
        >
          <Info className="w-5 h-5" />
          <span className="text-[11px] leading-none">Tentang</span>
        </button>
      </div>
    </div>
  );
};
