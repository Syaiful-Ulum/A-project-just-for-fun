import React from 'react';
import { BookOpen, Calendar, Lightbulb, Sparkles } from 'lucide-react';
import { formatIndonesianDate } from '../utils/dateUtils';
import { ActiveTab } from '../types';

interface HeaderProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  onOpenGuide: () => void;
  entriesCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  onOpenGuide,
  entriesCount,
}) => {
  const todayFormatted = formatIndonesianDate(new Date(), true);

  return (
    <header className="w-full bg-white/95 backdrop-blur-md border-b border-slate-200/80 sticky top-0 z-30 transition-all">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-3.5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          {/* Logo & Tagline */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-sky-500 to-blue-600 flex items-center justify-center text-white shadow-sm shadow-sky-500/20">
                <BookOpen className="w-5 h-5 stroke-[2.2]" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-lg sm:text-xl font-bold tracking-tight text-slate-900 leading-tight">
                    Share Daily Routine
                  </h1>
                  <span className="hidden xs:inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-sky-50 text-sky-700 border border-sky-200/60">
                    Jurnal Cepat
                  </span>
                </div>
                <p className="text-xs text-slate-500 font-medium">
                  Catat hari ini, pahami dirimu.
                </p>
              </div>
            </div>

            {/* Mobile guide button */}
            <button
              type="button"
              onClick={onOpenGuide}
              className="sm:hidden flex items-center gap-1 text-xs font-semibold text-sky-700 bg-sky-50 hover:bg-sky-100 border border-sky-200/80 px-2.5 py-1.5 rounded-xl transition-colors cursor-pointer"
              aria-label="Cara menggunakan aplikasi"
            >
              <Lightbulb className="w-3.5 h-3.5 text-amber-500" />
              <span>Panduan</span>
            </button>
          </div>

          {/* Right: Date and Action */}
          <div className="flex items-center justify-between sm:justify-end gap-3 pt-1 sm:pt-0 border-t sm:border-t-0 border-slate-100">
            <div className="flex items-center gap-1.5 text-xs sm:text-sm text-slate-600 bg-slate-100/80 px-3 py-1.5 rounded-xl font-medium">
              <Calendar className="w-3.5 h-3.5 text-sky-600" />
              <span>{todayFormatted}</span>
            </div>

            <button
              type="button"
              onClick={onOpenGuide}
              className="hidden sm:flex items-center gap-1.5 text-xs font-semibold text-slate-700 hover:text-sky-700 bg-slate-100/80 hover:bg-sky-50 border border-slate-200/60 hover:border-sky-200 px-3 py-1.5 rounded-xl transition-all cursor-pointer"
              aria-label="Cara menggunakan"
            >
              <Lightbulb className="w-4 h-4 text-amber-500" />
              <span>Cara Menggunakan</span>
            </button>
          </div>
        </div>

        {/* Desktop Navigation Tabs */}
        <nav className="mt-3 flex items-center gap-1 sm:gap-2 border-t border-slate-100 pt-2.5">
          <button
            type="button"
            onClick={() => setActiveTab('today')}
            className={`px-3.5 py-1.5 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'today'
                ? 'bg-sky-600 text-white shadow-sm shadow-sky-600/20'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <span>Hari Ini</span>
            {entriesCount > 0 && (
              <span
                className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                  activeTab === 'today'
                    ? 'bg-white/20 text-white'
                    : 'bg-slate-200 text-slate-700'
                }`}
              >
                {entriesCount}
              </span>
            )}
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('history')}
            className={`px-3.5 py-1.5 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'history'
                ? 'bg-sky-600 text-white shadow-sm shadow-sky-600/20'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <span>Riwayat</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('about')}
            className={`px-3.5 py-1.5 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'about'
                ? 'bg-sky-600 text-white shadow-sm shadow-sky-600/20'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <span>Tentang</span>
          </button>
        </nav>
      </div>
    </header>
  );
};
