import React, { useState } from 'react';
import { Clock, Edit2, Trash2, Check, X, Share2, AlertTriangle } from 'lucide-react';
import { MoodType, RoutineEntry } from '../types';
import { MOOD_OPTIONS } from '../constants';

interface RoutineListProps {
  entries: RoutineEntry[];
  isTodayDate: boolean;
  onUpdateEntry: (id: string, updated: { time: string; story: string; mood: MoodType }) => void;
  onDeleteEntry: (id: string) => void;
  onShareSingle: (entry: RoutineEntry) => void;
}

export const RoutineList: React.FC<RoutineListProps> = ({
  entries,
  isTodayDate,
  onUpdateEntry,
  onDeleteEntry,
  onShareSingle,
}) => {
  // Editing state
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTime, setEditTime] = useState('');
  const [editStory, setEditStory] = useState('');
  const [editMood, setEditMood] = useState<MoodType>('Senang');

  // Deleting confirmation state
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  const startEdit = (entry: RoutineEntry) => {
    setEditingId(entry.id);
    setEditTime(entry.time);
    setEditStory(entry.story);
    setEditMood(entry.mood);
    setConfirmDeleteId(null);
  };

  const cancelEdit = () => {
    setEditingId(null);
  };

  const saveEdit = (id: string) => {
    if (!editStory.trim()) return;
    onUpdateEntry(id, {
      time: editTime,
      story: editStory.trim(),
      mood: editMood,
    });
    setEditingId(null);
  };

  const sortedEntries = [...entries].sort((a, b) => a.time.localeCompare(b.time));

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between px-1">
        <h3 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight flex items-center gap-2">
          <span>Catatan {isTodayDate ? 'Hari Ini' : 'Hari'}</span>
          <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-slate-200/80 text-slate-700">
            {sortedEntries.length}
          </span>
        </h3>
        <span className="text-xs text-slate-400">Urut berdasarkan waktu</span>
      </div>

      <div className="space-y-3">
        {sortedEntries.map((entry) => {
          const isEditing = editingId === entry.id;
          const isConfirmingDelete = confirmDeleteId === entry.id;
          const moodInfo = MOOD_OPTIONS.find((m) => m.id === entry.mood);

          if (isEditing) {
            return (
              <div
                key={entry.id}
                className="bg-white rounded-2xl p-4 sm:p-5 border-2 border-sky-400 shadow-md transition-all"
              >
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-bold uppercase tracking-wider text-sky-700">
                    Edit Catatan
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => saveEdit(entry.id)}
                      className="px-3 py-1.5 rounded-xl bg-sky-600 text-white text-xs font-semibold hover:bg-sky-700 transition-colors flex items-center gap-1 cursor-pointer"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>Simpan</span>
                    </button>
                    <button
                      type="button"
                      onClick={cancelEdit}
                      className="px-2.5 py-1.5 rounded-xl bg-slate-100 text-slate-600 text-xs font-medium hover:bg-slate-200 transition-colors cursor-pointer"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold text-slate-500">Waktu:</span>
                    <input
                      type="time"
                      value={editTime}
                      onChange={(e) => setEditTime(e.target.value)}
                      className="px-2.5 py-1 rounded-lg bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-800"
                    />
                  </div>

                  <textarea
                    rows={2}
                    value={editStory}
                    onChange={(e) => setEditStory(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 text-slate-800 text-sm focus:bg-white focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500"
                  />

                  <div>
                    <label className="block text-xs font-medium text-slate-500 mb-1.5">
                      Pilih Mood:
                    </label>
                    <div className="flex flex-wrap gap-1.5">
                      {MOOD_OPTIONS.map((m) => (
                        <button
                          key={m.id}
                          type="button"
                          onClick={() => setEditMood(m.id)}
                          className={`px-2.5 py-1 rounded-xl text-xs font-medium border cursor-pointer transition-all ${
                            editMood === m.id
                              ? 'bg-sky-600 text-white border-sky-600 font-bold'
                              : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                          }`}
                        >
                          {m.emoji} {m.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            );
          }

          return (
            <div
              key={entry.id}
              className="group bg-white rounded-2xl p-4 sm:p-5 border border-slate-200/80 hover:border-slate-300/80 shadow-2xs hover:shadow-sm transition-all"
            >
              {/* Delete confirmation banner */}
              {isConfirmingDelete ? (
                <div className="flex flex-col xs:flex-row items-center justify-between gap-3 p-3 bg-rose-50 border border-rose-200 rounded-xl">
                  <div className="flex items-center gap-2 text-rose-800 text-xs sm:text-sm font-medium">
                    <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                    <span>Hapus catatan ini?</span>
                  </div>
                  <div className="flex items-center gap-2 w-full xs:w-auto justify-end">
                    <button
                      type="button"
                      onClick={() => setConfirmDeleteId(null)}
                      className="px-3 py-1.5 rounded-lg bg-white border border-slate-200 text-slate-700 text-xs font-semibold hover:bg-slate-50 transition-colors cursor-pointer"
                    >
                      Batal
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        onDeleteEntry(entry.id);
                        setConfirmDeleteId(null);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-rose-600 text-white text-xs font-semibold hover:bg-rose-700 transition-colors cursor-pointer"
                    >
                      Hapus
                    </button>
                  </div>
                </div>
              ) : (
                /* Standard layout: Responsive between desktop horizontal and mobile card */
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                  {/* Left: Time and Story */}
                  <div className="flex-1 flex flex-col sm:flex-row sm:items-start gap-2.5 sm:gap-4">
                    {/* Time badge */}
                    <div className="flex items-center gap-1 text-xs font-bold text-sky-700 bg-sky-50 px-2.5 py-1 rounded-xl w-fit shrink-0">
                      <Clock className="w-3.5 h-3.5 text-sky-600" />
                      <span>{entry.time}</span>
                    </div>

                    {/* Story content */}
                    <div className="flex-1">
                      <p className="text-sm sm:text-base text-slate-800 leading-relaxed whitespace-pre-wrap break-words">
                        {entry.story}
                      </p>
                    </div>
                  </div>

                  {/* Right: Mood Chip & Action Buttons */}
                  <div className="flex items-center justify-between sm:justify-end gap-2 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100">
                    {/* Mood Chip */}
                    <span
                      className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-semibold border ${
                        moodInfo?.badgeBg || 'bg-slate-100 text-slate-700 border-slate-200'
                      }`}
                    >
                      <span>{moodInfo?.emoji}</span>
                      <span>{entry.mood}</span>
                    </span>

                    {/* Actions: Share, Edit, Delete */}
                    <div className="flex items-center gap-1 text-slate-400">
                      <button
                        type="button"
                        onClick={() => onShareSingle(entry)}
                        className="p-1.5 rounded-lg hover:text-sky-600 hover:bg-sky-50 transition-colors cursor-pointer"
                        title="Bagikan catatan ini"
                        aria-label="Bagikan catatan ini"
                      >
                        <Share2 className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => startEdit(entry)}
                        className="p-1.5 rounded-lg hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
                        title="Edit catatan"
                        aria-label="Edit catatan"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => setConfirmDeleteId(entry.id)}
                        className="p-1.5 rounded-lg hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                        title="Hapus catatan"
                        aria-label="Hapus catatan"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
