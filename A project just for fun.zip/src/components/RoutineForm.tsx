import React, { useState, useEffect } from 'react';
import { Clock, Plus, Sparkles, AlertCircle } from 'lucide-react';
import { MoodType } from '../types';
import { MOOD_OPTIONS, DEFAULT_MOOD } from '../constants';
import { getCurrentTimeString } from '../utils/dateUtils';

interface RoutineFormProps {
  userName: string;
  selectedDate: string;
  onAddEntry: (entry: { time: string; story: string; mood: MoodType }) => void;
  onRequireName: () => void;
}

export const RoutineForm: React.FC<RoutineFormProps> = ({
  userName,
  selectedDate,
  onAddEntry,
  onRequireName,
}) => {
  const [story, setStory] = useState('');
  const [time, setTime] = useState(getCurrentTimeString());
  const [selectedMood, setSelectedMood] = useState<MoodType>(DEFAULT_MOOD);
  const [errorMsg, setErrorMsg] = useState('');

  // Update default time every minute if user hasn't typed anything yet
  useEffect(() => {
    const timer = setInterval(() => {
      if (!story) {
        setTime(getCurrentTimeString());
      }
    }, 60000);
    return () => clearInterval(timer);
  }, [story]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // 1. Validate name
    if (!userName.trim()) {
      setErrorMsg('Harap masukkan nama kamu terlebih dahulu di bagian atas.');
      onRequireName();
      return;
    }

    // 2. Validate story
    if (!story.trim()) {
      setErrorMsg('Yuk tulis sedikit apa yang terjadi sebelum menyimpan.');
      return;
    }

    // Clear error
    setErrorMsg('');

    // 3. Save entry
    onAddEntry({
      time: time || getCurrentTimeString(),
      story: story.trim(),
      mood: selectedMood,
    });

    // 4. Reset form
    setStory('');
    setTime(getCurrentTimeString());
    setSelectedMood(DEFAULT_MOOD);
  };

  const handleResetTimeToNow = () => {
    setTime(getCurrentTimeString());
  };

  return (
    <div className="bg-white rounded-3xl p-5 sm:p-7 border border-slate-200/80 shadow-2xs">
      <div className="mb-4">
        <h2 className="text-lg sm:text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
          <span>Apa yang terjadi hari ini?</span>
        </h2>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          Tulis kegiatan, cerita, pencapaian, atau keluh kesahmu...
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Story Textarea */}
        <div>
          <textarea
            id="routine-story-input"
            rows={3}
            value={story}
            onChange={(e) => {
              setStory(e.target.value);
              if (errorMsg) setErrorMsg('');
            }}
            placeholder="Contoh: Pagi ini saya bangun lebih awal, kemudian bekerja dan menyelesaikan beberapa tugas penting..."
            className="w-full px-4 py-3.5 rounded-2xl bg-slate-50/70 border border-slate-200 text-slate-800 placeholder-slate-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 transition-all text-sm sm:text-base leading-relaxed resize-y min-h-[105px]"
          />
        </div>

        {/* Time Selector */}
        <div className="flex flex-col xs:flex-row xs:items-center justify-between gap-2 pt-1">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-sky-600" />
              <span>Waktu Aktivitas</span>
            </span>
            <input
              type="time"
              value={time}
              onChange={(e) => setTime(e.target.value)}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-150 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 cursor-pointer"
            />
            <button
              type="button"
              onClick={handleResetTimeToNow}
              className="text-[11px] font-semibold text-sky-700 hover:text-sky-800 hover:underline px-1 py-0.5 cursor-pointer"
              title="Gunakan jam saat ini"
            >
              Sekarang
            </button>
          </div>
          <span className="text-[11px] text-slate-400 hidden sm:inline">
            Format 24 jam (HH:MM)
          </span>
        </div>

        {/* Mood / Perasaan Selection */}
        <div className="pt-2">
          <div className="flex items-center justify-between mb-2.5">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-600">
              Bagaimana perasaanmu?
            </label>
            <span className="text-xs font-semibold text-sky-700 bg-sky-50 px-2 py-0.5 rounded-lg">
              {MOOD_OPTIONS.find((m) => m.id === selectedMood)?.emoji}{' '}
              {selectedMood}
            </span>
          </div>

          <div className="grid grid-cols-2 xs:grid-cols-4 gap-2">
            {MOOD_OPTIONS.map((mood) => {
              const isSelected = selectedMood === mood.id;
              return (
                <button
                  key={mood.id}
                  type="button"
                  onClick={() => setSelectedMood(mood.id)}
                  className={`px-3 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold transition-all flex items-center justify-center gap-2 border cursor-pointer ${
                    isSelected
                      ? 'bg-sky-600 text-white border-sky-600 shadow-sm shadow-sky-600/25 scale-[1.02]'
                      : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200/90 hover:border-slate-300'
                  }`}
                  aria-pressed={isSelected}
                >
                  <span className="text-base leading-none">{mood.emoji}</span>
                  <span className="truncate">{mood.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Validation error message */}
        {errorMsg && (
          <div className="flex items-center gap-2 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-medium">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Submit Button */}
        <div className="pt-2">
          <button
            type="submit"
            className="w-full py-3.5 px-6 rounded-2xl bg-sky-600 hover:bg-sky-700 active:bg-sky-800 text-white text-base font-bold transition-all shadow-md shadow-sky-600/20 hover:shadow-sky-600/30 flex items-center justify-center gap-2 cursor-pointer"
          >
            <Plus className="w-5 h-5 stroke-[2.5]" />
            <span>+ Tambah Catatan</span>
          </button>
        </div>
      </form>
    </div>
  );
};
