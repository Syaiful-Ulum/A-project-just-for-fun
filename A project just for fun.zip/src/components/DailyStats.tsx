import React from 'react';
import { Share2, Clock, Moon, Smile, Sparkles } from 'lucide-react';
import { DaySummary, MoodType } from '../types';
import { MOOD_OPTIONS } from '../constants';

interface DailyStatsProps {
  summary: DaySummary;
  isTodayDate: boolean;
  onShare: () => void;
}

export const DailyStats: React.FC<DailyStatsProps> = ({
  summary,
  isTodayDate,
  onShare,
}) => {
  const { totalCount, dominantMood, firstActivityTime, lastActivityTime } = summary;

  const dominantMoodObj = MOOD_OPTIONS.find((m) => m.id === dominantMood);

  if (totalCount === 0) {
    return (
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/80 shadow-2xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-bold text-slate-900 tracking-tight flex items-center gap-1.5">
              <span>Ringkasan {isTodayDate ? 'Hari Ini' : 'Hari'}</span>
            </h3>
            <p className="text-slate-600 text-xs sm:text-sm mt-1">
              Belum ada cerita {isTodayDate ? 'hari ini' : 'pada tanggal ini'}.
            </p>
            <p className="text-slate-400 text-xs mt-0.5">
              Yuk mulai dengan mencatat apa yang sedang kamu lakukan.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/80 shadow-2xs">
      <div className="flex items-center justify-between gap-3 mb-4">
        <div>
          <h3 className="text-sm sm:text-base font-bold text-slate-900 tracking-tight">
            Ringkasan {isTodayDate ? 'Hari Ini' : 'Hari'}
          </h3>
          <p className="text-xs text-slate-500">
            Dihitung otomatis dari {totalCount} catatan yang tersimpan
          </p>
        </div>

        <button
          type="button"
          onClick={onShare}
          className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-sky-50 hover:bg-sky-100 text-sky-700 border border-sky-200/80 text-xs sm:text-sm font-semibold transition-all shadow-2xs hover:shadow-sm cursor-pointer"
          title="Bagikan ringkasan harian"
        >
          <Share2 className="w-3.5 h-3.5 stroke-[2.2]" />
          <span>Bagikan</span>
        </button>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3">
        {/* Total Catatan */}
        <div className="bg-slate-50/90 rounded-2xl p-3 border border-slate-100 flex flex-col justify-between">
          <span className="text-[11px] font-semibold text-slate-500 flex items-center gap-1">
            <span>📝</span> Catatan
          </span>
          <p className="text-lg sm:text-xl font-bold text-slate-900 mt-1">
            {totalCount} <span className="text-xs font-normal text-slate-500">aktivitas</span>
          </p>
        </div>

        {/* Mood Dominan */}
        <div className="bg-amber-50/60 rounded-2xl p-3 border border-amber-100/80 flex flex-col justify-between">
          <span className="text-[11px] font-semibold text-amber-800 flex items-center gap-1">
            <span>{dominantMoodObj?.emoji || '😊'}</span> Mood Dominan
          </span>
          <p className="text-base sm:text-lg font-bold text-amber-950 mt-1 truncate">
            {dominantMood || 'Senang'}
          </p>
        </div>

        {/* Aktivitas Pertama */}
        <div className="bg-sky-50/60 rounded-2xl p-3 border border-sky-100/80 flex flex-col justify-between">
          <span className="text-[11px] font-semibold text-sky-800 flex items-center gap-1">
            <Clock className="w-3.5 h-3.5 text-sky-600" /> Mulai
          </span>
          <p className="text-base sm:text-lg font-bold text-sky-950 mt-1">
            {firstActivityTime || '--:--'}
          </p>
        </div>

        {/* Aktivitas Terakhir */}
        <div className="bg-indigo-50/60 rounded-2xl p-3 border border-indigo-100/80 flex flex-col justify-between">
          <span className="text-[11px] font-semibold text-indigo-800 flex items-center gap-1">
            <Moon className="w-3.5 h-3.5 text-indigo-600" /> Terakhir
          </span>
          <p className="text-base sm:text-lg font-bold text-indigo-950 mt-1">
            {lastActivityTime || '--:--'}
          </p>
        </div>
      </div>
    </div>
  );
};
