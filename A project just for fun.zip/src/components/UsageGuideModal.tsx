import React from 'react';
import { X, Lightbulb, CheckCircle2 } from 'lucide-react';

interface UsageGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const UsageGuideModal: React.FC<UsageGuideModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const steps = [
    {
      num: '1',
      title: 'Masukkan nama kamu',
      desc: 'Cukup sekali di awal, kamu bisa mengubahnya kapan saja.',
    },
    {
      num: '2',
      title: 'Tulis apa yang kamu lakukan atau rasakan',
      desc: 'Bisa kegiatan kerja, istirahat, momen menyenangkan, atau keluh kesah.',
    },
    {
      num: '3',
      title: 'Pilih perasaanmu',
      desc: 'Klik salah satu tombol mood yang paling menggambarkan suasana hatimu.',
    },
    {
      num: '4',
      title: 'Klik "+ Tambah Catatan"',
      desc: 'Catatan langsung tersimpan aman di browsermu seketika.',
    },
    {
      num: '5',
      title: 'Lihat kembali ceritamu melalui Riwayat',
      desc: 'Buka tab Riwayat untuk melihat perjalanan harimu dari waktu ke waktu.',
    },
  ];

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="guide-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs transition-all animate-in fade-in"
    >
      <div
        className="bg-white rounded-3xl p-6 sm:p-7 max-w-md w-full shadow-xl border border-slate-100 relative"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center">
              <Lightbulb className="w-4 h-4" />
            </div>
            <h3 id="guide-modal-title" className="text-base sm:text-lg font-bold text-slate-900">
              Cara Menggunakan
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
            aria-label="Tutup panduan"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mt-4 space-y-3">
          {steps.map((step) => (
            <div
              key={step.num}
              className="flex items-start gap-3 p-3 rounded-2xl bg-slate-50 border border-slate-100/80"
            >
              <span className="w-6 h-6 rounded-full bg-sky-600 text-white font-bold text-xs flex items-center justify-center shrink-0 mt-0.5 shadow-2xs">
                {step.num}
              </span>
              <div>
                <p className="text-xs sm:text-sm font-bold text-slate-800">
                  {step.title}
                </p>
                <p className="text-xs text-slate-500 mt-0.5 leading-relaxed">
                  {step.desc}
                </p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-5 pt-3 border-t border-slate-100">
          <button
            type="button"
            onClick={onClose}
            className="w-full py-3 rounded-2xl bg-sky-600 hover:bg-sky-700 text-white text-xs sm:text-sm font-bold transition-all shadow-sm shadow-sky-600/20 cursor-pointer"
          >
            Mengerti, Ayo Mulai!
          </button>
        </div>
      </div>
    </div>
  );
};
