import React, { useState } from 'react';
import { Calendar, ChevronRight, Share2, Sparkles, Clock } from 'lucide-react';
import { RoutineEntry } from '../types';
import { calculateDaySummary, formatIndonesianDate, isToday } from '../utils/dateUtils';
import { MOOD_OPTIONS } from '../constants';

interface HistoryViewProps {
  entries: RoutineEntry[];
  onSelectDate: (date: string) => void;
  onShareDay: (date: string) => void;
}

export const HistoryView: React.FC<HistoryViewProps> = ({
  entries,
  onSelectDate,
  onShareDay,
}) => {
  // Group entries by date
  const groupedByDate: Record<string, RoutineEntry[]> = {};
  for (const entry of entries) {
    if (!groupedByDate[entry.date]) {
      groupedByDate[entry.date] = [];
    }
    groupedByDate[entry.date].push(entry);
  }

  // Sort dates descending
  const sortedDates = Object.keys(groupedByDate).sort((a, b) => b.localeCompare(a));

  const [expandedDate, setExpandedDate] = useState<string | null>(null);

  const toggleExpand = (date: string) => {
    setExpandedDate((prev) => (prev === date ? null : date));
  };

  if (sortedDates.length === 0) {
    return (
      <div className="bg-white rounded-3xl p-8 sm:p-12 border border-slate-200/80 shadow-2xs text-center max-w-lg mx-auto">
        <div className="w-16 h-16 rounded-3xl bg-sky-50 border border-sky-100 flex items-center justify-center text-sky-600 mb-4 mx-auto">
          <Calendar className="w-8 h-8 text-sky-600" />
        </div>
        <h3 className="text-xl font-bold text-slate-900 tracking-tight">
          Belum ada riwayat jurnal
        </h3>
        <p className="text-slate-500 text-sm mt-2 leading-relaxed">
          Setiap catatan harian yang kamu simpan akan otomatis terkumpul di sini. Mulai tulis rutinitas pertamamu di tab Hari Ini!
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="bg-gradient-to-br from-white to-slate-50/70 rounded-3xl p-5 sm:p-6 border border-slate-200/80 shadow-2xs">
        <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
          <span>Riwayat Jurnal</span>
          <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-sky-100 text-sky-800">
            {sortedDates.length} Hari Tercatat
          </span>
        </h2>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          Daftar seluruh hari yang pernah kamu isi. Klik untuk melihat detail atau membuka di jurnal.
        </p>
      </div>

      <div className="space-y-3">
        {sortedDates.map((date) => {
          const dayEntries = groupedByDate[date];
          const summary = calculateDaySummary(dayEntries);
          const dominantMoodObj = MOOD_OPTIONS.find((m) => m.id === summary.dominantMood);
          const isCurrentToday = isToday(date);
          const isExpanded = expandedDate === date;

          return (
            <div
              key={date}
              className="bg-white rounded-2xl border border-slate-200/80 hover:border-slate-300 shadow-2xs transition-all overflow-hidden"
            >
              <div className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <h3 className="text-base sm:text-lg font-bold text-slate-900">
                      {formatIndonesianDate(date, true)}
                    </h3>
                    {isCurrentToday && (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-sky-100 text-sky-800">
                        Hari Ini
                      </span>
                    )}
                  </div>

                  <div className="flex flex-wrap items-center gap-2 sm:gap-4 mt-1.5 text-xs sm:text-sm text-slate-600">
                    <span className="font-semibold text-slate-700">
                      {dayEntries.length} catatan
                    </span>
                    <span className="text-slate-300">•</span>
                    <span className="inline-flex items-center gap-1 font-medium">
                      <span>{dominantMoodObj?.emoji || '😊'}</span>
                      <span>Mood dominan: {summary.dominantMood || 'Senang'}</span>
                    </span>
                    {summary.firstActivityTime && (
                      <>
                        <span className="text-slate-300 hidden xs:inline">•</span>
                        <span className="text-slate-500 hidden xs:inline">
                          {summary.firstActivityTime} - {summary.lastActivityTime}
                        </span>
                      </>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-center">
                  <button
                    type="button"
                    onClick={() => onShareDay(date)}
                    className="p-2 rounded-xl text-slate-500 hover:text-sky-600 hover:bg-sky-50 border border-slate-200 hover:border-sky-200 transition-colors cursor-pointer"
                    title="Bagikan ringkasan tanggal ini"
                    aria-label="Bagikan"
                  >
                    <Share2 className="w-4 h-4" />
                  </button>

                  <button
                    type="button"
                    onClick={() => toggleExpand(date)}
                    className="px-3 py-2 rounded-xl text-xs font-semibold text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 transition-colors cursor-pointer"
                  >
                    {isExpanded ? 'Tutup Detail' : 'Lihat Detail'}
                  </button>

                  <button
                    type="button"
                    onClick={() => onSelectDate(date)}
                    className="flex items-center gap-1 px-3.5 py-2 rounded-xl text-xs font-semibold text-white bg-sky-600 hover:bg-sky-700 transition-colors shadow-2xs cursor-pointer"
                  >
                    <span>Buka</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Inline expandable details */}
              {isExpanded && (
                <div className="border-t border-slate-100 bg-slate-50/60 p-4 sm:p-5 space-y-2.5">
                  <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
                    Catatan pada {formatIndonesianDate(date, false)}
                  </div>
                  {dayEntries
                    .sort((a, b) => a.time.localeCompare(b.time))
                    .map((item) => {
                      const itemMood = MOOD_OPTIONS.find((m) => m.id === item.mood);
                      return (
                        <div
                          key={item.id}
                          className="bg-white p-3 rounded-xl border border-slate-200/70 flex items-start gap-3 text-xs sm:text-sm"
                        >
                          <span className="font-bold text-sky-700 shrink-0 font-mono">
                            {item.time}
                          </span>
                          <span className="flex-1 text-slate-700">{item.story}</span>
                          <span className="shrink-0 px-2 py-0.5 rounded-lg bg-slate-100 text-slate-700 text-xs font-medium flex items-center gap-1">
                            <span>{itemMood?.emoji}</span>
                            <span className="hidden xs:inline">{item.mood}</span>
                          </span>
                        </div>
                      );
                    })}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
