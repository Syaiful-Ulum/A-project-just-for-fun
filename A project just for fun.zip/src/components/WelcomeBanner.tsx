import React, { useState } from 'react';
import { Edit3, Check, User, Sparkles } from 'lucide-react';

interface WelcomeBannerProps {
  userName: string;
  onSaveName: (name: string) => void;
}

export const WelcomeBanner: React.FC<WelcomeBannerProps> = ({
  userName,
  onSaveName,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [tempName, setTempName] = useState(userName);
  const [inputError, setInputError] = useState('');

  const handleStartJournaling = (e: React.FormEvent) => {
    e.preventDefault();
    if (!tempName.trim()) {
      setInputError('Silakan masukkan nama kamu terlebih dahulu.');
      return;
    }
    setInputError('');
    onSaveName(tempName.trim());
    setIsEditing(false);
  };

  const handleStartEdit = () => {
    setTempName(userName);
    setIsEditing(true);
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!tempName.trim()) {
      setInputError('Nama tidak boleh kosong.');
      return;
    }
    setInputError('');
    onSaveName(tempName.trim());
    setIsEditing(false);
  };

  // If user has not introduced themselves yet
  if (!userName && !isEditing) {
    return (
      <div className="bg-gradient-to-br from-white to-sky-50/60 rounded-3xl p-6 sm:p-8 border border-sky-100 shadow-sm transition-all">
        <div className="max-w-xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-100 text-sky-800 text-xs font-semibold mb-3">
            <Sparkles className="w-3.5 h-3.5 text-sky-600" />
            <span>Selamat Datang</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            Kenalan dulu 👋
          </h2>
          <p className="text-slate-600 text-sm sm:text-base mt-1.5 leading-relaxed">
            Masukkan nama kamu untuk mulai mencatat rutinitas harian dengan nyaman dan cepat.
          </p>

          <form onSubmit={handleStartJournaling} className="mt-5 flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <input
                type="text"
                value={tempName}
                onChange={(e) => {
                  setTempName(e.target.value);
                  if (inputError) setInputError('');
                }}
                placeholder="Masukkan nama kamu..."
                className="w-full px-4 py-3 rounded-2xl bg-white border border-slate-200 text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 transition-all text-sm sm:text-base shadow-2xs font-medium"
                autoFocus
                maxLength={40}
              />
              {inputError && (
                <p className="text-xs text-rose-500 font-medium mt-1.5 ml-1">
                  {inputError}
                </p>
              )}
            </div>
            <button
              type="submit"
              className="px-6 py-3 rounded-2xl bg-sky-600 hover:bg-sky-700 active:bg-sky-800 text-white font-semibold text-sm sm:text-base transition-all shadow-sm shadow-sky-600/20 cursor-pointer shrink-0"
            >
              Mulai Journaling
            </button>
          </form>
        </div>
      </div>
    );
  }

  // Editing existing name
  if (isEditing) {
    return (
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/80 shadow-sm transition-all">
        <form onSubmit={handleSaveEdit} className="max-w-md">
          <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">
            Ubah Nama Panggilan
          </label>
          <div className="flex gap-2">
            <input
              type="text"
              value={tempName}
              onChange={(e) => {
                setTempName(e.target.value);
                if (inputError) setInputError('');
              }}
              placeholder="Masukkan nama kamu..."
              className="w-full px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 text-slate-800 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 text-sm font-medium"
              autoFocus
              maxLength={40}
            />
            <button
              type="submit"
              className="px-4 py-2 rounded-xl bg-sky-600 text-white text-xs font-semibold hover:bg-sky-700 transition-colors flex items-center gap-1 cursor-pointer shrink-0"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Simpan</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setTempName(userName);
                setIsEditing(false);
              }}
              className="px-3 py-2 rounded-xl bg-slate-100 text-slate-600 text-xs font-medium hover:bg-slate-200 transition-colors cursor-pointer shrink-0"
            >
              Batal
            </button>
          </div>
          {inputError && (
            <p className="text-xs text-rose-500 font-medium mt-1.5 ml-1">
              {inputError}
            </p>
          )}
        </form>
      </div>
    );
  }

  // Active greeting view
  return (
    <div className="bg-gradient-to-r from-sky-50/70 via-indigo-50/40 to-slate-50 rounded-3xl p-5 sm:p-6 border border-sky-100/80 shadow-2xs transition-all">
      <div className="flex items-start sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
              Hai, {userName}! 👋
            </h2>
            <button
              type="button"
              onClick={handleStartEdit}
              title="Ubah nama"
              aria-label="Ubah nama"
              className="p-1.5 rounded-lg text-slate-400 hover:text-sky-600 hover:bg-sky-100/60 transition-colors cursor-pointer"
            >
              <Edit3 className="w-4 h-4" />
            </button>
          </div>
          <p className="text-slate-600 text-sm sm:text-base mt-1 font-normal">
            Bagaimana harimu hari ini? Yuk ceritakan apa saja yang terjadi.
          </p>
        </div>

        <div className="hidden md:flex items-center gap-2 bg-white/80 backdrop-blur-xs px-3.5 py-2 rounded-2xl border border-sky-100/80 shadow-2xs">
          <div className="w-8 h-8 rounded-full bg-sky-100 text-sky-700 flex items-center justify-center font-bold text-sm">
            {userName.charAt(0).toUpperCase()}
          </div>
          <div className="text-left">
            <p className="text-xs font-semibold text-slate-700 leading-none truncate max-w-[120px]">
              {userName}
            </p>
            <p className="text-[11px] text-slate-400 leading-none mt-1">Jurnal Pribadi</p>
          </div>
        </div>
      </div>
    </div>
  );
};
