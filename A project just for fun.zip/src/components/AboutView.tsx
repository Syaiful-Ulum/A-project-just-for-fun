import React, { useState } from 'react';
import { BookOpen, ShieldCheck, Heart, Sparkles, Zap, Trash2, CheckCircle2 } from 'lucide-react';

interface AboutViewProps {
  onClearAllData: () => void;
  entriesCount: number;
}

export const AboutView: React.FC<AboutViewProps> = ({
  onClearAllData,
  entriesCount,
}) => {
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  return (
    <div className="max-w-2xl mx-auto space-y-5">
      {/* Hero card */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-2xs text-center">
        <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-sky-500 to-blue-600 flex items-center justify-center text-white mx-auto mb-4 shadow-sm shadow-sky-500/20">
          <BookOpen className="w-7 h-7 stroke-[2.2]" />
        </div>
        <h2 className="text-2xl font-bold text-slate-900 tracking-tight">
          Share Daily Routine
        </h2>
        <p className="text-sky-700 font-semibold text-sm mt-1">
          Catat harimu. Kenali dirimu.
        </p>
        <p className="text-slate-600 text-sm sm:text-base mt-3 leading-relaxed max-w-lg mx-auto">
          Tempat sederhana untuk mencatat perjalanan harianmu. Dirancang agar siapa saja dapat mencatat rutinitas dan perasaannya tanpa ribet, tanpa registrasi, dan tanpa login.
        </p>
      </div>

      {/* Purpose & Highlights */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-2xs">
        <h3 className="text-base font-bold text-slate-900 mb-4 tracking-tight">
          Mengapa Aplikasi Ini Dibuat?
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 flex items-start gap-3">
            <div className="w-8 h-8 rounded-xl bg-sky-100 text-sky-700 flex items-center justify-center shrink-0 mt-0.5">
              <Zap className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-slate-900">Mengingat Aktivitas</h4>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Mencatat timeline kejadian penting dari pagi hingga malam agar harimu lebih terstruktur.
              </p>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 flex items-start gap-3">
            <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center shrink-0 mt-0.5">
              <Heart className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-slate-900">Memahami Mood</h4>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Melihat dinamika emosi dan perasaan agar kamu lebih peka terhadap kesehatan mentalmu.
              </p>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 flex items-start gap-3">
            <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0 mt-0.5">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-slate-900">Melihat Pola Rutinitas</h4>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Menemukan kebiasaan baik dan waktu produktif terbaikmu setiap harinya.
              </p>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 flex items-start gap-3">
            <div className="w-8 h-8 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center shrink-0 mt-0.5">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-slate-900">100% Privat di Browser</h4>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Data kamu tersimpan di penyimpanan lokal perangkat (localStorage), tanpa server pengumpul data.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Storage & Reset Section */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/80 shadow-2xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h4 className="text-sm font-bold text-slate-900">Penyimpanan Perangkat</h4>
            <p className="text-xs text-slate-500 mt-0.5">
              Saat ini ada <strong>{entriesCount}</strong> catatan tersimpan di browser ini.
            </p>
          </div>

          {!showClearConfirm ? (
            <button
              type="button"
              onClick={() => setShowClearConfirm(true)}
              className="text-xs font-semibold text-rose-600 hover:text-rose-700 bg-rose-50 hover:bg-rose-100 px-3.5 py-2 rounded-xl transition-colors cursor-pointer flex items-center gap-1.5 w-fit"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Hapus Semua Data</span>
            </button>
          ) : (
            <div className="flex items-center gap-2">
              <span className="text-xs text-rose-700 font-medium">Yakin bersihkan data?</span>
              <button
                type="button"
                onClick={() => {
                  onClearAllData();
                  setShowClearConfirm(false);
                }}
                className="px-3 py-1.5 bg-rose-600 text-white rounded-xl text-xs font-bold hover:bg-rose-700 transition-colors cursor-pointer"
              >
                Ya, Hapus
              </button>
              <button
                type="button"
                onClick={() => setShowClearConfirm(false)}
                className="px-3 py-1.5 bg-slate-100 text-slate-700 rounded-xl text-xs font-semibold hover:bg-slate-200 transition-colors cursor-pointer"
              >
                Batal
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
